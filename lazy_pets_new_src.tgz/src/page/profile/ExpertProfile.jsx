"use client";

import { useMemo, useState } from "react";
import { iconSrc } from "@/icons/sources";
import { primeSessionCache, useSession } from "@/context/SessionContext";
import { accountFor } from "@/data/mock/accounts";
import { homeExpert } from "@/data/mock/home";
import { loadRegisteredCategories } from "@/lib/expertCategories";
import { clearAuthStorage } from "@/lib/preferences";
import { navigate } from "@/lib/navigation";
import appConfig from "../../../appconfig.json";

const roleLabel = {
  pet: "寵物服務",
  repair: "維修安裝服務",
};

const ALL_CATEGORIES = ["pet", "repair"];

function formatPhone(phone) {
  const digits = String(phone ?? "").replace(/\D/g, "");
  if (digits.length !== 8) return digits || "—";
  return `+852 ${digits.slice(0, 4)} ${digits.slice(4)}`;
}

function resolveRegisteredCategories(sessionRegistered, fallbackRole) {
  const stored = loadRegisteredCategories();
  if (stored.length > 0) return stored;
  if (sessionRegistered && (fallbackRole === "pet" || fallbackRole === "repair")) {
    return [fallbackRole];
  }
  return [];
}

export default function ExpertProfile() {
  const session = useSession();
  const registered = session?.authenticated === true && session?.registered === true;
  const phone = session?.phone ?? "";
  const account = accountFor(phone);
  const role = session?.role ?? account?.role ?? "pet";

  const categories = useMemo(
    () => resolveRegisteredCategories(registered, role),
    [registered, role],
  );
  const canAddCategory = registered && categories.length < ALL_CATEGORIES.length;

  const [loggingOut, setLoggingOut] = useState(false);

  async function logout() {
    if (loggingOut) return;
    setLoggingOut(true);
    clearAuthStorage();
    primeSessionCache({ authenticated: false });
    navigate("/login", "replace");
  }

  const statusMessage = !registered
    ? "尚未完成專家註冊，完成後即可接單。"
    : categories.length >= ALL_CATEGORIES.length
      ? "你已登記寵物同維修服務，可接兩邊嘅單。"
      : "你已完成一項專家註冊，可以再加多一項服務類別。";

  return (
    <div className="px-4 pb-10 pt-6">
      <div className="flex flex-col items-center rounded-2xl bg-white px-5 py-8 shadow-[0_8px_24px_rgba(77,82,87,0.06)]">
        <img
          src={iconSrc["avatar"]}
          alt=""
          aria-hidden
          className="size-20 object-contain"
        />
        <h2 className="mt-4 text-[20px] font-bold leading-7 text-[#4d5257]">
          {homeExpert.displayName}
        </h2>
        <p className="mt-1 text-[14px] leading-5 text-[#797979]">{formatPhone(phone)}</p>
        {categories.length > 0 ? (
          <div className="mt-3 flex flex-wrap justify-center gap-2">
            {categories.map((cat) => (
              <span
                key={cat}
                className="inline-flex rounded-full bg-[#e7f7fb] px-3 py-1 text-[12px] font-medium text-[#0091b2]"
              >
                {roleLabel[cat] ?? cat}
              </span>
            ))}
          </div>
        ) : (
          <p className="mt-3 inline-flex rounded-full bg-[#eef0f2] px-3 py-1 text-[12px] font-medium text-[#797979]">
            未登記
          </p>
        )}
        <p className="mt-4 text-center text-[14px] leading-5 text-[#797979]">{statusMessage}</p>
        {!registered ? (
          <button
            type="button"
            onClick={() => navigate("/apply/role")}
            className={`mt-5 inline-flex h-11 w-full max-w-xs items-center justify-center rounded-xl bg-brand px-4 text-title font-medium text-white transition active:bg-brand-active`}
          >
            完成註冊
          </button>
        ) : null}
        {canAddCategory ? (
          <button
            type="button"
            onClick={() => navigate("/apply/role")}
            className={`mt-5 inline-flex h-11 w-full max-w-xs items-center justify-center rounded-xl border border-[#0091b2] bg-white px-4 text-title font-medium text-[#0091b2] transition active:bg-[#e7f7fb]`}
          >
            加入更多服務類別
          </button>
        ) : null}
      </div>

      <button
        type="button"
        disabled={loggingOut}
        onClick={logout}
        className={`mt-8 inline-flex h-12 w-full items-center justify-center rounded-xl border border-[#dfe3e6] bg-white px-4 text-[16px] font-medium text-[#d95959] transition active:bg-[#f3f5f7] disabled:opacity-60`}
      >
        {loggingOut ? "登出中…" : "登出"}
      </button>

      <p className="mt-6 text-center text-micro text-[#797979]">{appConfig.version} 版本</p>
    </div>
  );
}

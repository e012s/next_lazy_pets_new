"use client";
import { useEffect, useRef, useState } from "react";
import useAuthenticate from "@/actions/Authenticate";
import { clearAuthStorage, loadLocale } from "@/lib/preferences";
import { primeSessionCache } from "@/context/SessionContext";
import { profileFromStoredUser } from "@/lib/clientSession";
import { navigate } from "@/lib/navigation";

const REJECTED = "此電話號碼未能登入";

export default function Verification({ phone = "" }) {
    const { login, verification } = useAuthenticate();
    const digits = String(phone).replace(/\D/g, "");
    const validPhone = digits.length === 8;
    const [code, setCode] = useState(["", "", "", "", "", ""]);
    const [timer, setTimer] = useState(28);
    const [toast, setToast] = useState("");
    const [notice, setNotice] = useState(validPhone ? "" : REJECTED);
    const [isLoading, setIsLoading] = useState(false);
    const inputs = useRef([]);
    useEffect(() => {
        const id = window.setInterval(() => {
            setTimer((current) => (current <= 0 ? 0 : current - 1));
        }, 1000);
        return () => window.clearInterval(id);
    }, []);
    function focusAt(index) {
        inputs.current[index]?.focus();
    }
    async function finish(entered) {
        if (!validPhone || entered.length !== 6 || isLoading) {
            setNotice(REJECTED);
            setToast(REJECTED);
            setCode(["", "", "", "", "", ""]);
            focusAt(0);
            return;
        }
        setIsLoading(true);
        const result = await verification({
            locale: loadLocale(),
            phone: digits,
            code: entered,
            device_type: "1",
        });
        if (!result?.status || !result.data?.token) {
            setIsLoading(false);
            const message = result?.message ?? REJECTED;
            setNotice(message);
            setToast(message);
            setCode(["", "", "", "", "", ""]);
            focusAt(0);
            return;
        }
        const sessionData = profileFromStoredUser(result.data);
        setIsLoading(false);
        if (!sessionData?.next) {
            const message = result?.message || REJECTED;
            setNotice(message);
            setToast(message);
            setCode(["", "", "", "", "", ""]);
            focusAt(0);
            return;
        }
        primeSessionCache(sessionData);
        if (document.activeElement instanceof HTMLElement)
            document.activeElement.blur();
        navigate(sessionData.next, "replace");
    }
    function applyDigits(start, digitsInput) {
        const next = [...code];
        const chars = digitsInput.replace(/\D/g, "").slice(0, 6 - start);
        if (!chars)
            return;
        for (let offset = 0; offset < chars.length; offset += 1) {
            next[start + offset] = chars[offset] ?? "";
        }
        setCode(next);
        const joined = next.join("");
        if (joined.length === 6 && next.every(Boolean)) {
            finish(joined);
            return;
        }
        focusAt(Math.min(start + chars.length, 5));
    }
    function onKeyDown(event, index) {
        if (event.key !== "Backspace")
            return;
        event.preventDefault();
        if (code[index]) {
            const next = [...code];
            next[index] = "";
            setCode(next);
            return;
        }
        if (index > 0) {
            const next = [...code];
            next[index - 1] = "";
            setCode(next);
            focusAt(index - 1);
        }
    }
    async function resend() {
        if (timer > 0 || isLoading)
            return;
        if (!validPhone) {
            setNotice(REJECTED);
            setToast(REJECTED);
            return;
        }
        setIsLoading(true);
        const res = await login({
            locale: loadLocale(),
            device_type: "1",
            phone: digits,
        });
        setIsLoading(false);
        if (!res?.status) {
            const message = res?.message ?? "發送失敗，請稍後再試";
            setNotice(message);
            setToast(message);
            return;
        }
        setTimer(28);
        setToast("驗證碼已重新發送");
        setNotice("");
    }
    const clock = timer.toString().padStart(2, "0");
    return (<div className="verification-page relative">
        <div className="verification-container">
            <div className="verification-header">
                驗證碼將以短訊形式
                <br />
                傳送到以下電話號碼
            </div>
            <div className="phone-number">+852 {digits || phone}</div>
            <div className="verification-prompt">請輸入短訊上的驗證碼</div>
            <div className="verification-input-container">
                {code.map((digit, index) => (<input key={index} ref={(node) => {
                    inputs.current[index] = node;
                }} type="text" inputMode="numeric" pattern="[0-9]*" autoComplete={index === 0 ? "one-time-code" : "off"} maxLength={1} value={digit} data-index={index} className="verification-input" aria-label={`驗證碼第 ${index + 1} 位`} disabled={isLoading} onChange={(event) => applyDigits(index, event.target.value)} onKeyDown={(event) => onKeyDown(event, index)} onPaste={(event) => {
                    event.preventDefault();
                    applyDigits(index, event.clipboardData.getData("text"));
                }} />))}
            </div>
            {notice ? (<p className="verify-error" role="alert">
                {notice}
            </p>) : null}
            <button type="button" className="resend-button" onClick={resend} disabled={timer > 0 || isLoading}>
                重新發送驗證碼 (00:{clock})
            </button>
            <div className="help-text">
                如未能收到驗證碼，請重新
                <a className="help-link" href="/login" onClick={() => clearAuthStorage()}>
                    輸入電話號碼
                </a>
            </div>
        </div>
        {toast ? (<button type="button" className="auth-toast" onClick={() => setToast("")}>
            {toast}
        </button>) : null}
    </div>);
}

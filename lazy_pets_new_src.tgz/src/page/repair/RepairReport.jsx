"use client";
import { getRepairOrder } from "@/data/mock/repair";
import { RegisterDataPrompt, useNeedsRegistration } from "@/components/RegisteredData";
import ServiceReport from "@/components/ServiceReport";
import { repairReportFields } from "@/lib/reportFields";

export default function RepairReport({ id }) {
  const order = id ? getRepairOrder(id) : undefined;
  const needsRegistration = useNeedsRegistration();
  if (needsRegistration) {
    return (
      <div className="px-5 py-4">
        <RegisterDataPrompt afterRegistered="即可查看訂單。" />
      </div>
    );
  }
  if (!order) {
    return <p className="px-4 py-8 text-sm text-[#797979]">找不到這張維修單。</p>;
  }
  return <ServiceReport variant="repair" {...repairReportFields(order)} />;
}

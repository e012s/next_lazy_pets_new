"use client";
import { iconSrc } from "@/icons/sources";
import { navigate } from "@/lib/navigation";
import { useState } from "react";
import { repairOrders } from "@/data/mock/repair";
import { ContactSheet } from "@/components/ContactSheet";
import { RepairOrderTabs } from "@/components/RepairOrderTabs";
import { RegisteredData } from "@/components/RegisteredData";
export default function RepairOrders() {
  const orders = repairOrders.filter((order) => order.status === "in_progress");
  const [contactId, setContactId] = useState(null);
  const contact = orders.find((order) => order.id === contactId);
  return (<div>
    <RepairOrderTabs current="open" />
    <div className="space-y-3 px-5 py-4">
      <RegisteredData afterRegistered="即可查看訂單。">
        {orders.length === 0 ? (<p className="rounded-2xl bg-white px-4 py-10 text-center text-sm text-[#797979]">未有進行中的維修單</p>) : (orders.map((order) => (<article key={order.id} className="rounded-2xl bg-white p-4 shadow-[0_8px_24px_rgba(77,82,87,0.06)]">
          <div className="flex gap-3">
            <img src={iconSrc["repair-ac"]} alt="" aria-hidden className="inline-block object-contain size-12 shrink-0" />
            <div className="min-w-0 flex-1">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h2 className="text-[15px] font-medium text-[#4d5257]">{order.title}</h2>
                  <p className="text-[13px] text-[#797979]">{order.code}</p>
                </div>
                <span className="shrink-0 rounded-full bg-[#fdecee] px-2.5 py-1 text-[12px] font-medium text-[#d95959]">
                  {order.badge}
                </span>
              </div>
            </div>
          </div>
          <ul className="mt-3 space-y-2 text-[13px] leading-5 text-[#4d5257]">
            <li>
              <span className="block text-[12px] text-[#797979]">服務時間</span>
              {order.schedule}
            </li>
            <li>
              <span className="block text-[12px] text-[#797979]">地址</span>
              {order.place}
            </li>
            <li>
              <span className="block text-[12px] text-[#797979]">報價</span>
              <span className="font-medium text-[#0091b2]">{order.pay}</span>
              <span className="text-[#797979]"> · {order.payNote}</span>
            </li>
          </ul>
          <p className="mt-3 text-sm leading-6 text-[#797979]">{order.note}</p>
          <div className="mt-4 grid grid-cols-2 gap-3">
            <button type="button" className="inline-flex h-11 w-full items-center justify-center rounded-xl border border-brand bg-white px-4 text-title font-medium text-brand transition active:bg-brand-outline-active focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand" onClick={() => setContactId(order.id)}>
              聯絡客人
            </button>
            <button type="button" onClick={() => navigate(`/repair/orders/${order.id}/report`)} className="inline-flex h-11 w-full items-center justify-center gap-1 rounded-xl bg-brand px-4 text-title font-medium text-white transition active:bg-brand-active focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand">
              提交報告
            </button>
          </div>
        </article>)))}
      </RegisteredData>
    </div>
    {contact ? (<ContactSheet name={contact.contactName} phoneNumber={contact.contactPhone} meta={`${contact.title} · ${contact.code}`} onClose={() => setContactId(null)} />) : null}
  </div>);
}

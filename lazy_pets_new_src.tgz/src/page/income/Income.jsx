"use client";
import { iconSrc } from "@/icons/sources";
import { navigate } from "@/lib/navigation";
import { useLayoutEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { incomeRecords, incomeSummary } from "@/data/mock/income";
import { money } from "@/lib/format";
import { ShellNotice } from "@/components/ShellNotice";
import { RegisteredData } from "@/components/RegisteredData";
function RowIcon({ icon }) {
  const className = "size-12 shrink-0 object-contain";
  const key =
    icon === "groom"
      ? "pet-groom"
      : icon === "boarding"
        ? "pet-boarding"
        : icon === "visit"
          ? "pet-walk"
          : "pet-walk";
  return <img src={iconSrc[key]} alt="" aria-hidden className={className} />;
}
export default function Income() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [statement, setStatement] = useState(false);

  useLayoutEffect(() => {
    setOpen(false);
    setStatement(false);
  }, [pathname]);

  const visible = open ? incomeRecords : incomeRecords.filter((record) => record.featured);
  return (<div className="space-y-3 px-5 py-4">
    <section className="rounded-2xl bg-[#0091b2] px-5 py-5 text-white">
      <p className="text-sm text-white/80">{incomeSummary.monthLabel}</p>
      <p className="mt-2 text-[40px] leading-none font-bold">{money(incomeSummary.payout)}</p>
      <div className="mt-5 grid grid-cols-3 gap-2 border-t border-white/20 pt-4 text-center">
        <div>
          <p className="text-[12px] text-white/75">已完成</p>
          <p className="mt-1 text-lg font-medium">{incomeSummary.doneCount} 單</p>
        </div>
        <div>
          <p className="text-[12px] text-white/75">待完成</p>
          <p className="mt-1 text-lg font-medium">{money(incomeSummary.pending)}</p>
        </div>
        <div>
          <p className="text-[12px] text-white/75">今年累計</p>
          <p className="mt-1 text-lg font-medium">{money(incomeSummary.yearTotal)}</p>
        </div>
      </div>
    </section>
    <ShellNotice>{incomeSummary.notice}</ShellNotice>
    <section className="rounded-2xl bg-white p-4">
      <h2 className="text-[15px] font-medium text-[#4d5257]">9月明細</h2>
      <p className="mt-1 text-[12px] text-[#797979]">點擊開啟收入明細</p>
      <RegisteredData afterRegistered="即可查看收入明細。">
        <ul className="mt-2 divide-y divide-[#eef1f4]">
          {visible.map((record) => (<li key={record.id}>
            <button type="button" onClick={() => navigate(`/income/${record.id}`)} className="flex w-full items-center gap-3 py-3 text-left">
              <RowIcon icon={record.icon} />
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm text-[#4d5257]">{record.title}</span>
                <span className="block text-[12px] text-[#797979]">{record.meta}</span>
              </span>
              <span className="text-right">
                <span className={`block text-sm font-medium${record.status === "pending" ? " text-[#4d5257]" : " text-[#0091b2]"}`}>
                  {record.status === "pending" ? money(record.payout) : `+${money(record.payout)}`}
                </span>
                <span className={`mt-1 inline-flex rounded-full px-2 py-0.5 text-[11px]${record.status === "pending" ? " bg-[#fdecee] text-[#d95959]" : " bg-[#f2f4f6] text-[#797979]"}`}>
                  {record.status === "pending" ? "待完成" : "已完成"}
                </span>
              </span>
            </button>
          </li>))}
        </ul>
        <p className="mt-2 text-center text-sm font-medium text-[#0091b2]">
          <button type="button" onClick={() => setOpen((value) => !value)}>
            {open ? "收起紀錄" : "查看全部紀錄"}
          </button>
          <span className="text-[#c5c8cc]"> · </span>
          <button type="button" onClick={() => setStatement((value) => !value)}>
            下載月結單
          </button>
        </p>
        {statement ? (<pre className="mt-2 overflow-x-auto rounded-xl bg-[#f6f8fa] p-3 text-[12px] leading-5 whitespace-pre-wrap text-[#4d5257]">
          {`Lazy Pets 9月專家結單（預覽，未產生 PDF）\n已完成 ${incomeSummary.doneCount} 單\n待發放 ${money(incomeSummary.payout)}\n發放日 2026/10/07 FPS\n上次發放 ${incomeSummary.lastPayout}`}
        </pre>) : null}
      </RegisteredData>
    </section>
    <p className="flex items-center justify-center gap-1 pb-4 text-[12px] text-[#797979]">
      <img src={iconSrc["check"]} alt="" aria-hidden className="inline-block object-contain size-4 text-[#1f8a4d]" />
      上次發放 {incomeSummary.lastPayout}
    </p>
  </div>);
}

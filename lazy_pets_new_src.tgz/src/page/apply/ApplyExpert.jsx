import ApplyExpertPet from "@/pages/apply/ApplyExpertPet";
import ApplyExpertRepair from "@/pages/apply/ApplyExpertRepair";

/** Single apply shell: pet vs repair only differ in category-specific sections. */
export default function ApplyExpert({ category }) {
  if (category === "repair") return <ApplyExpertRepair />;
  return <ApplyExpertPet />;
}

export const APPLY_CATEGORIES = ["pet", "repair"];

export function normalizeApplyCategory(value) {
  return value === "repair" ? "repair" : "pet";
}

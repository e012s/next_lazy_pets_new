"use client";
import { iconSrc } from "@/icons/sources";
import { navigate } from "@/lib/navigation";
import { useEffect, useState } from "react";
import { readApplySubmittedSummary } from "@/lib/applySubmittedSummary";

function Glyph({ src, className }) {
  return <img src={src} alt="" aria-hidden className={`inline-block object-contain ${className ?? ""}`} />;
}

function ApplySubmittedStepper() {
  const steps = [
    { n: "1", label: "提交申請", state: "done" },
    { n: "2", label: "審批中", state: "active" },
    { n: "3", label: "未驗證", state: "upcoming" },
  ];
  return (
    <ol className="flex w-full items-start px-10 pt-6">
      {steps.flatMap((step, index) => {
        const nodes = [];
        if (index > 0) {
          nodes.push(
            <li key={`step-line-${index}`} className="flex h-7 min-w-5 flex-1 items-center" aria-hidden>
              <span className={`h-0.5 w-full${index === 1 ? " bg-brand" : " bg-[#c6ccd2]"}`} />
            </li>,
          );
        }
        nodes.push(
          <li key={step.label} className="flex shrink-0 flex-col items-center text-center">
            <span
              className={`flex size-7 items-center justify-center rounded-full text-[14px] leading-5 font-bold${step.state === "done" ? " bg-brand text-white" : ""} ${step.state === "active" ? " bg-brand text-white" : ""} ${step.state === "upcoming" ? " border-2 border-[#b9b9b9] bg-white text-[#b9b9b9]" : ""}`}
            >
              {step.state === "done" ? (
                <Glyph src="/icons/form-check-white.svg" className="size-3.5" />
              ) : (
                step.n
              )}
            </span>
            <span
              className={`mt-1.5 block text-[13px] leading-5${step.state === "active" ? " font-bold text-brand" : " font-normal text-muted"}`}
            >
              {step.label}
            </span>
          </li>,
        );
        return nodes;
      })}
    </ol>
  );
}

function SummaryRow({ label, value }) {
  return (
    <div className="flex items-center justify-between gap-3 border-b border-[#eef0f3] py-3.5 last:border-b-0">
      <span className="shrink-0 text-[14px] leading-5 font-normal text-muted">{label}</span>
      <span className="text-right text-[14px] leading-5 font-bold">{value}</span>
    </div>
  );
}

function yesNo(uploaded) {
  return uploaded ? "已上傳" : "未上傳";
}

function repairSummaryRows(summary) {
  return [
    { label: "申請類別", value: summary.category },
    { label: "已選服務", value: `${summary.serviceCount} 項` },
    { label: "香港身份證", value: yesNo(summary.idUploaded) },
    { label: "相關牌照", value: `${summary.licenseFilled} / ${summary.licenseMax} (可後補)` },
    { label: "過往工程相片", value: `${summary.photoCount} 張` },
  ];
}

function petSummaryRows(summary) {
  const rows = [
    { label: "申請類別", value: summary.category },
    { label: "已選服務", value: `${summary.serviceCount} 項` },
    { label: "服務地區", value: `${summary.regionCount} 區` },
    { label: "可接受體型", value: `${summary.sizeCount} 項` },
  ];
  if (summary.boardingCap) {
    rows.push({ label: "寄宿可接數量", value: summary.boardingCap });
    rows.push({
      label: "動物寄養所牌照",
      value: yesNo(summary.boardingLicenseUploaded),
    });
  }
  rows.push({ label: "香港身份證", value: yesNo(summary.idUploaded) });
  rows.push({
    label: "其他相關證書",
    value: `${summary.certificateCount} 項 (可後補)`,
  });
  return rows;
}

export default function ApplySubmitted() {
  const [summary, setSummary] = useState(null);

  useEffect(() => {
    setSummary(readApplySubmittedSummary());
  }, []);

  const rows = summary ? (summary.kind === "pet" ? petSummaryRows(summary) : repairSummaryRows(summary)) : null;
  const editHref = summary?.kind === "pet" ? "/apply/pet" : "/apply/repair";

  return (
    <div className="bg-[#f9fafc] px-[15px] pb-10">
      <ApplySubmittedStepper />

      <div className="mt-8 text-center">
        <div className="mx-auto flex items-center justify-center overflow-hidden rounded-full">
          <img src={iconSrc["submitted"]} alt="" aria-hidden className="inline-block object-contain size-[80px]" />
        </div>
        <h2 className="mt-5 text-[20px] leading-7 font-bold">申請已提交</h2>
        <p className="mx-auto mt-2 max-w-[320px] text-[14px] leading-5 font-normal text-muted">
          我們會於 1–2 個工作天內完成審批，結果會以短訊及 App 通知你。
        </p>
      </div>

      <div className="mt-6 rounded-lg border border-[#c6ccd2] bg-white px-4 py-1">
        {rows
          ? rows.map((row) => <SummaryRow key={row.label} label={row.label} value={row.value} />)
          : <p className="py-6 text-center text-[14px] leading-5 text-muted">載入申請摘要…</p>}
      </div>

      {summary ? (
        <button
          type="button"
          onClick={() => navigate(editHref)}
          className="mt-6 flex h-12 w-full items-center justify-center rounded-lg border border-brand bg-white text-[16px] leading-6 font-bold text-brand"
        >
          修改申請
        </button>
      ) : null}
      <p className="mt-4 text-center text-[12px] leading-[18px] font-normal text-muted">
        修改後需重新審批，通常 1–2 個工作天
      </p>
    </div>
  );
}

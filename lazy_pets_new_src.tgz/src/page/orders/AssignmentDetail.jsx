"use client";
import { navigate } from "@/lib/navigation";
import { useState } from "react";
import { getAssignment } from "@/data/mock/assignments";
import { ContactSheet } from "@/components/ContactSheet";
import { RegisterDataPrompt, useNeedsRegistration } from "@/components/RegisteredData";
export default function AssignmentDetail({ id }) {
  const assignment = id ? getAssignment(id) : undefined;
  const needsRegistration = useNeedsRegistration();
  const [started, setStarted] = useState(assignment?.status === "in_progress" || assignment?.status === "done");
  const [contact, setContact] = useState(false);
  if (needsRegistration) {
    return (
      <div className="px-5 py-4">
        <RegisterDataPrompt afterRegistered="即可查看訂單。" />
      </div>
    );
  }
  if (!assignment || assignment.status === "done") {
    return <p className="px-4 py-8 text-sm text-[#797979]">找不到這張進行中的訂單。</p>;
  }
  return (<div className="space-y-3 px-5 py-4">
    <section className="rounded-2xl bg-white p-4 shadow-[0_8px_24px_rgba(77,82,87,0.05)]">
      <p className="text-[12px] text-[#797979]">{assignment.code}</p>
      <h2 className="mt-1 text-lg font-medium text-[#4d5257]">{assignment.title}</h2>
      <p className="mt-1 text-sm text-[#797979]">{assignment.subtitle}</p>
      {assignment.petProfile ? (
        <p className="mt-3 text-sm leading-6 text-[#4d5257]">{assignment.petProfile}</p>
      ) : null}
      <p className="mt-2 text-sm leading-6 text-[#797979]">{assignment.note}</p>
    </section>
    <section className="rounded-2xl bg-white p-4 text-sm shadow-[0_8px_24px_rgba(77,82,87,0.05)]">
      <p className="text-[12px] text-[#797979]">{assignment.scheduleLabel}</p>
      <p className="mt-1 text-[#4d5257]">{assignment.schedule}</p>
      <p className="mt-3 text-[12px] text-[#797979]">{assignment.placeLabel}</p>
      <p className="mt-1 text-[#4d5257]">
        {started || assignment.status !== "accepted" ? assignment.place : "開始服務後先顯示詳細地址"}
      </p>
      <p className="mt-3 text-[12px] text-[#797979]">服務酬勞</p>
      <p className="mt-1 font-medium text-[#0091b2]">
        {assignment.payMain} · {assignment.payNote}
      </p>
    </section>
    {started ? <p className="rounded-xl bg-[#e7f7fb] px-3 py-3 text-sm text-[#0f5f73]">服務已開始，可以提交報告。</p> : null}
    <div className="space-y-3">
      <button type="button" onClick={() => navigate(`/orders/${assignment.id}/map`)} className="inline-flex h-11 w-full items-center justify-center gap-1 rounded-xl bg-brand px-4 text-title font-medium text-white transition active:bg-brand-active focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand">
        查看地圖
      </button>
      <div className="grid grid-cols-2 gap-3">
        <button type="button" className="inline-flex h-11 w-full items-center justify-center rounded-xl border border-brand bg-white px-4 text-title font-medium text-brand transition active:bg-brand-outline-active focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand" onClick={() => setContact(true)}>
          聯絡客人
        </button>
        {started ? (<button type="button" onClick={() => navigate(`/orders/${assignment.id}/report`)} className="inline-flex h-11 w-full items-center justify-center rounded-xl border border-brand bg-white px-4 text-title font-medium text-brand transition active:bg-brand-outline-active focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand">
          提交報告
        </button>) : (<button type="button" className="inline-flex h-11 w-full items-center justify-center rounded-xl border border-brand bg-white px-4 text-title font-medium text-brand transition active:bg-brand-outline-active focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand" onClick={() => setStarted(true)}>
          開始服務
        </button>)}
      </div>
    </div>
    {contact ? (<ContactSheet name={assignment.contactName} phoneNumber={assignment.contactPhone} meta={`${assignment.title} · ${assignment.code}`} onClose={() => setContact(false)} />) : null}
  </div>);
}

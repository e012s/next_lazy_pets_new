"use client";
import { getAssignment } from "@/data/mock/assignments";
import { RegisterDataPrompt, useNeedsRegistration } from "@/components/RegisteredData";
import ServiceReport from "@/components/ServiceReport";
import { petReportFields } from "@/lib/reportFields";

export default function PetReport({ id }) {
  const assignment = id ? getAssignment(id) : undefined;
  const needsRegistration = useNeedsRegistration();
  if (needsRegistration) {
    return (
      <div className="px-5 py-4">
        <RegisterDataPrompt afterRegistered="即可查看訂單。" />
      </div>
    );
  }
  if (!assignment) {
    return <p className="px-4 py-8 text-sm text-[#797979]">找不到這張訂單。</p>;
  }
  return <ServiceReport variant="pet" {...petReportFields(assignment)} />;
}

"use client";

import { getAssignment } from "@/data/mock/assignments";
import { FeeCard } from "@/components/OrderBlocks";
import { PhotoRow } from "@/components/PhotoRow";
import { navigate } from "@/lib/navigation";
import { RegisterDataPrompt, useNeedsRegistration } from "@/components/RegisteredData";
export default function PetCompletedDetail({ id }) {
  const needsRegistration = useNeedsRegistration();
  const assignment = id ? getAssignment(id) : undefined;
  if (needsRegistration) {
    return (
      <div className="px-5 py-4">
        <RegisterDataPrompt afterRegistered="即可查看訂單。" />
      </div>
    );
  }
  if (!assignment || assignment.status !== "done") {
    return <p className="px-4 py-8 text-sm text-[#797979]">找不到這張已完成訂單。</p>;
  }
  return (<div className="space-y-3 px-5 py-4 pb-8">
    <section className="rounded-2xl bg-white p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-[12px] text-[#797979]">{assignment.code}</p>
          <h2 className="mt-1 text-lg font-medium text-[#4d5257]">{assignment.title}</h2>
          <p className="mt-1 text-sm text-[#797979]">{assignment.subtitle}</p>
        </div>
        <span className="rounded-full bg-[#e7f6ee] px-2.5 py-1 text-xs font-medium text-[#1f8a4d]">{assignment.badge}</span>
      </div>
      {assignment.petProfile ? (
        <p className="mt-3 text-sm leading-6 text-[#4d5257]">{assignment.petProfile}</p>
      ) : null}
      <p className="mt-2 text-sm leading-6 text-[#797979]">{assignment.note}</p>
    </section>
    <section className="rounded-2xl bg-white p-4 text-sm">
      <p className="text-[12px] text-[#797979]">{assignment.scheduleLabel}</p>
      <p className="mt-1 text-[#4d5257]">{assignment.schedule}</p>
      <p className="mt-3 text-[12px] text-[#797979]">{assignment.placeLabel}</p>
      <p className="mt-1 text-[#4d5257]">{assignment.place}</p>
      <div className="mt-4">
        <PhotoRow count={2} />
      </div>
    </section>
    <FeeCard orderTotal={200} platformFee={40} income={160} incomeFormula="" payoutNote="已計入 9 月結單，10月7日以 FPS 發放" />
    <button type="button" onClick={() => navigate(`/orders/${assignment.id}/report`)} className="inline-flex h-11 w-full items-center justify-center gap-1 rounded-xl bg-brand px-4 text-title font-medium text-white transition active:bg-brand-active focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand">
      查看報告
    </button>
    <button type="button" onClick={() => navigate("/income/inc-cl52301")} className="inline-flex h-11 w-full items-center justify-center rounded-xl border border-brand bg-white px-4 text-title font-medium text-brand transition active:bg-brand-outline-active focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand">
      查看收入明細
    </button>
    <button type="button" onClick={() => navigate("/orders")} className="inline-flex h-11 w-full items-center justify-center rounded-xl border border-brand bg-white px-4 text-title font-medium text-brand transition active:bg-brand-outline-active focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand">
      返回我的訂單
    </button>
  </div>);
}

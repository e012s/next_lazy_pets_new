"use client";
import { iconSrc } from "@/icons/sources";
import { navigate } from "@/lib/navigation";
import { useLayoutEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { listMyOrders } from "@/data/mock/assignments";
import { ContactSheet } from "@/components/ContactSheet";
import { RegisteredData } from "@/components/RegisteredData";
const tabs = [
  { id: "today", label: "今日" },
  { id: "upcoming", label: "即將" },
  { id: "done", label: "已完成" },
];
const badgeClass = {
  alert: "bg-[#ffdcdb] text-[#d95959]",
  brand: "bg-[#0091b2] text-white",
  muted: "bg-[#eef0f2] text-[#797979]",
  ok: "bg-[#e7f6ee] text-[#1f8a4d]",
};
const outlineBtn =
  "inline-flex h-[44px] w-full items-center justify-center rounded-[8px] border border-[#0091b2] bg-white px-4 text-[16px] font-bold text-[#0091b2] transition active:bg-brand-outline-active focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand";
function KindIcon({ kind }) {
  if (kind === "repair") {
    return <img src={iconSrc["repair-ac"]} alt="" aria-hidden className="inline-block object-contain size-[50px] shrink-0" />;
  }
  const key = kind === "groom" ? "pet-groom" : kind === "boarding" ? "pet-boarding" : "pet-walk";
  return <img src={iconSrc[key]} alt="" aria-hidden className="inline-block object-contain size-[50px] shrink-0" />;
}
function Section({ icon, label, last, children }) {
  return (
    <div className={`py-[15px]${!last ? " border-b border-[#c6ccd2]" : ""}`}>
      <div className="flex items-center gap-2">
        <img src={iconSrc[icon]} alt="" aria-hidden className="inline-block object-contain size-4" />
        <span className="text-[14px] font-bold leading-5 text-[#4d5257]">{label}</span>
      </div>
      <div className="mt-[6px] pl-6">{children}</div>
    </div>
  );
}
export default function MyOrders() {
  const pathname = usePathname();
  const [tab, setTab] = useState("today");
  const [contact, setContact] = useState(null);

  useLayoutEffect(() => {
    setTab("today");
    setContact(null);
  }, [pathname]);

  const orders = listMyOrders();
  const todayCount = orders.filter((item) => item.tab === "today").length;
  const visible = orders.filter((item) => item.tab === tab);
  return (<div>
    <div className="grid h-[46px] grid-cols-3 bg-[#4d5257] text-[14px]" role="tablist">
      {tabs.map((item) => {
        const active = tab === item.id;
        const label = item.id === "today" ? `${item.label} · ${todayCount}` : item.label;
        return (<button key={item.id} type="button" role="tab" aria-selected={active} onClick={() => setTab(item.id)} className={`h-full ${active ? " font-bold text-white shadow-[inset_0_-3px_0_#28c6ed]" : " font-normal text-[#b9b9b9]"}`}>
          {label}
        </button>);
      })}
    </div>
    <div className="flex flex-col gap-5 px-[15px] pt-5 pb-5">
      <RegisteredData afterRegistered="即可查看訂單。">
        {visible.length === 0 ? (<p className="rounded-[8px] border border-[#c6ccd2] bg-white px-4 py-10 text-center text-sm text-[#797979]">這個分類未有訂單</p>) : (visible.map((order) => (<article key={order.id} className="rounded-[8px] border border-[#c6ccd2] bg-white p-5">
          <div className="flex items-start gap-[14px] pb-1.5">
            <KindIcon kind={order.kind} />
            <button type="button" onClick={() => navigate(`/orders/${order.id}`)} className="min-w-0 flex-1 text-left">
              <h2 className="text-[16px] font-bold leading-normal text-[#4d5257]">{order.title} · {order.code}</h2>
              <p className="mt-1 text-[14px] leading-5 text-[#797979]">{order.subtitle}</p>
            </button>
            <span className={`inline-flex h-5 shrink-0 items-center rounded-full px-3 text-[12px] font-medium ${badgeClass[order.badgeTone] ?? badgeClass.muted}`}>
              {order.badge}
            </span>
          </div>
          <Section icon="budget" label="服務酬勞">
            <p className="leading-7">
              <span className="text-[18px] font-bold text-[#0091b2]">{order.payMain}</span>
              <span className="text-[14px] text-[#797979]">{"　·　"}{order.payNote}</span>
            </p>
          </Section>
          <Section icon="order-clock" label={order.scheduleLabel}>
            <p className="text-[14px] leading-5 text-[#797979]">{order.schedule}</p>
          </Section>
          <Section icon="order-location" label={order.placeLabel}>
            <p className="text-[14px] leading-5 text-[#797979]">{order.place}</p>
            <button type="button" onClick={() => navigate(`/orders/${order.id}/map`)} className="mt-[10px] inline-flex h-10 items-center justify-center rounded-[8px] bg-[#0091b2] px-[18px] text-[14px] font-bold text-white transition active:bg-brand-active focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand">
              查看地圖
            </button>
          </Section>
          <div
            className={
              order.tab === "upcoming" || order.tab === "done"
                ? "pt-[14px]"
                : "grid grid-cols-2 gap-[14px] pt-[14px]"
            }
          >
            {order.tab === "upcoming" ? (
              <button
                type="button"
                onClick={() => navigate(`/orders/${order.id}`)}
                className={outlineBtn}
              >
                查看訂單詳情
              </button>
            ) : order.tab === "done" ? (
              <button
                type="button"
                onClick={() => navigate(`/orders/${order.id}`)}
                className={outlineBtn}
              >
                查看訂單詳情及報告
              </button>
            ) : (
              <>
                <button type="button" className={outlineBtn} onClick={() => setContact(order)}>
                  聯絡客人
                </button>
                {order.status === "in_progress" ? (
                  <button type="button" onClick={() => navigate(`/orders/${order.id}/report`)} className={outlineBtn}>
                    提交報告
                  </button>
                ) : (
                  <button type="button" onClick={() => navigate(`/orders/${order.id}`)} className={outlineBtn}>
                    開始服務
                  </button>
                )}
              </>
            )}
          </div>
        </article>)))}
      </RegisteredData>
    </div>
    {contact ? (<ContactSheet name={contact.contactName} phoneNumber={contact.contactPhone} meta={`${contact.title} · ${contact.code}`} onClose={() => setContact(null)} />) : null}
  </div>);
}

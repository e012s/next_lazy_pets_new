import { createHmac, timingSafeEqual } from "node:crypto";
import { accountFor } from "@/data/mock/accounts";
import { registeredFromSupplierUser } from "@/lib/supplierUser";
import appConfig from "../../appconfig.json";
/** HttpOnly session token. The browser never reads this value. */
export const SESSION_COOKIE = "lp_session";
/** HttpOnly signed list of phones that finished expert registration. Survives logout. */
export const REGISTERED_COOKIE = "lp_registered";
export const HOME = "/";
export const FIND_TASKS = "/find";
/** Shared screen after verify, before either apply form. */
export const APPLY_CHOOSER = "/apply/role";
const SECRET = appConfig.sessionSecret;
export { sessionCookieOptions } from "./sessionCookieOptions";

/** Demo / QA: set `forceRegistered` in root `appconfig.json` (`true` | `false`). Omit key to use API + cookies. */
function applyRegisteredOverride(registered) {
    if (typeof appConfig.forceRegistered === "boolean")
        return appConfig.forceRegistered;
    return registered;
}
function hmac(value) {
    return createHmac("sha256", SECRET).update(value).digest("base64url");
}
function safeEqual(a, b) {
    const left = Buffer.from(a);
    const right = Buffer.from(b);
    if (left.length !== right.length)
        return false;
    return timingSafeEqual(left, right);
}

/** Route handlers turn the HttpOnly cookie into this header before calling the mock API. */
export function bearerFromCookie(token) {
    return token ? `Bearer ${token}` : null;
}
function parseSessionToken(token) {
    if (!token)
        return null;
    const dot = token.lastIndexOf(".");
    if (dot <= 0)
        return null;
    const payload = token.slice(0, dot);
    const signature = token.slice(dot + 1);
    if (!safeEqual(signature, hmac(payload)))
        return null;
    try {
        const parsed = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
        if (!parsed.phone || !/^\d{8}$/.test(String(parsed.phone).replace(/\D/g, "")))
            return null;
        const phone = String(parsed.phone).replace(/\D/g, "");
        const registered = typeof parsed.registered === "boolean" ? parsed.registered : undefined;
        return { phone, registered };
    }
    catch {
        return null;
    }
}
export function phoneFromBearer(authorization) {
    if (!authorization?.startsWith("Bearer "))
        return null;
    return parseSessionToken(authorization.slice("Bearer ".length).trim())?.phone ?? null;
}
function signSession(phone, registered) {
    const digits = String(phone).replace(/\D/g, "");
    const body = { phone: digits, iat: Date.now() };
    if (typeof registered === "boolean")
        body.registered = registered;
    const payload = Buffer.from(JSON.stringify(body), "utf8").toString("base64url");
    return `${payload}.${hmac(payload)}`;
}

export function signSessionFromPhone(phone, registered) {
    return signSession(phone, registered);
}
export function phonesFromRegistration(token) {
    if (!token)
        return [];
    const dot = token.lastIndexOf(".");
    if (dot < 0)
        return [];
    const body = token.slice(0, dot);
    const signature = token.slice(dot + 1);
    if (!signature || !safeEqual(signature, hmac(body)))
        return [];
    if (!body)
        return [];
    return body.split(".").filter((phone) => /^\d{8}$/.test(phone));
}
export function registrationToken(phones) {
    const body = [...new Set(phones)].sort().join(".");
    return `${body}.${hmac(body)}`;
}

function registeredForPhone(phone, registeredToken, supplierUser, sessionRegistered) {
    const fromApi = registeredFromSupplierUser(supplierUser);
    if (fromApi === true)
        return true;
    if (fromApi === false)
        return false;
    if (sessionRegistered === true)
        return true;
    if (sessionRegistered === false)
        return false;
    return phonesFromRegistration(registeredToken).includes(phone);
}

/** Sync HttpOnly registration cookie with workspace user after OTP verify. */
export function registrationCookieForPhone(phone, registeredToken, supplierUser) {
    const fromApi = registeredFromSupplierUser(supplierUser);
    let phones = phonesFromRegistration(registeredToken);
    if (fromApi === true) {
        if (!phones.includes(phone))
            phones.push(phone);
        return registrationToken(phones);
    }
    if (fromApi === false) {
        phones = phones.filter((entry) => entry !== phone);
        if (phones.length === 0)
            return null;
        return registrationToken(phones);
    }
    return null;
}

export function profileAfterSupplierLogin(phone, registeredToken, supplierUser) {
    const digits = String(phone).replace(/\D/g, "");
    if (digits.length !== 8)
        return null;
    const provisional = signSessionFromPhone(digits);
    let profile = expertFromAuthorization(bearerFromCookie(provisional), registeredToken, supplierUser);
    if (!profile)
        return null;
    const sessionToken = signSessionFromPhone(digits, profile.registered);
    profile = expertFromAuthorization(bearerFromCookie(sessionToken), registeredToken, supplierUser);
    if (!profile)
        return null;
    let registeredCookieNext = null;
    let clearRegisteredCookie = false;
    if (profile.registered) {
        registeredCookieNext =
            registrationCookieForPhone(digits, registeredToken, supplierUser) ??
            registrationCookieForPhone(digits, registeredToken, { registered: true });
    }
    else {
        clearRegisteredCookie = true;
    }
    const workspaceToken =
        supplierUser && typeof supplierUser === "object" && "token" in supplierUser
            ? supplierUser.token
            : null;
    return { profile, sessionToken, workspaceToken, registeredCookieNext, clearRegisteredCookie };
}

/** Where a signed-in expert should land after login/verify: always home. */
export function entryPathForProfile() {
    return HOME;
}
function toProfile(account, registered) {
    const profile = { phone: account.phone, role: account.role, registered };
    return { ...profile, next: entryPathForProfile(profile) };
}

/** Issue a bearer token. Any 6-digit code is accepted for the two mock phones. */
export function authenticateExpert(phone, code) {
    const account = accountFor(phone);
    if (!account || !/^\d{6}$/.test(code)) {
        return { error: "此電話號碼未能登入" };
    }
    return { token: signSession(account.phone) };
}

/** Mock API entry. `authorization` must be `Bearer <lp_session>`. */
export function expertFromAuthorization(authorization, registeredToken, supplierUser) {
    if (!authorization?.startsWith("Bearer "))
        return null;
    const session = parseSessionToken(authorization.slice("Bearer ".length).trim());
    if (!session?.phone)
        return null;
    const phone = session.phone;
    const account = accountFor(phone);
    const role = account?.role ?? "pet";
    const registered = applyRegisteredOverride(registeredForPhone(phone, registeredToken, supplierUser, session.registered));
    return toProfile({ phone, role, hkIdApproved: account?.hkIdApproved ?? false }, registered);
}

/** Mock API write. Returns a new registration cookie value for the signed-in phone. */
export function registerExpert(authorization, registeredToken) {
    const phone = phoneFromBearer(authorization);
    if (!phone)
        return null;
    const account = accountFor(phone);
    const role = account?.role ?? "pet";
    const phones = phonesFromRegistration(registeredToken);
    if (!phones.includes(phone))
        phones.push(phone);
    return { token: registrationToken(phones), profile: toProfile({ phone, role }, applyRegisteredOverride(true)) };
}

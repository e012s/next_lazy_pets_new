import appConfig from "../../appconfig.json";

/** Real Lazy workspace API (same base URL as `appconfig.json` `apiBaseUrl`). */
export const LAZY_WORKSPACE_API_URL = appConfig.apiBaseUrl.replace(/\/$/, "");

/** Supplier / workspace token from real login (not the mock `lp_session`). */
export const WORKSPACE_TOKEN_COOKIE = "lp_workspace_token";

export type ThirdPartyGlobalPayload = {
  holidays?: unknown[];
  districts?: unknown[];
  regions?: { code?: string; name?: string }[];
  skills?: unknown;
  [key: string]: unknown;
};

export type LazyWorkspaceResponse<T> = {
  status: boolean;
  message?: string;
  data?: T;
  error?: string;
};

type PostWorkspaceOptions = {
  locale?: string;
  token?: string | null;
  body?: Record<string, unknown>;
};

async function postWorkspace<T>(
  endpoint: string,
  { locale = "cn", token = null, body = {} }: PostWorkspaceOptions = {},
): Promise<LazyWorkspaceResponse<T>> {
  const url = new URL(`${LAZY_WORKSPACE_API_URL}/${endpoint}`);
  url.searchParams.set("locale", locale);

  const headers: Record<string, string> = {
    "Content-Type": "application/json",
  };
  if (token) {
    headers.token = token;
  }

  try {
    const response = await fetch(url, {
      method: "POST",
      headers,
      body: JSON.stringify(body),
      cache: "no-store",
    });

    const json = (await response.json()) as LazyWorkspaceResponse<T>;
    if (!response.ok && json.status !== true) {
      return {
        status: false,
        message: json.message ?? "請求失敗",
        error: `HTTP ${response.status}`,
      };
    }
    return json;
  } catch (error) {
    const message = error instanceof Error ? error.message : "請求失敗";
    return { status: false, message, error: message };
  }
}

export type SupplierLoginPayload = {
  token?: string;
  [key: string]: unknown;
};

/** POST `third_party_global` — query `locale`, header `token` (f7_lazy_cleaner Axios style). */
export function postThirdPartyGlobal(
  options: PostWorkspaceOptions = {},
): Promise<LazyWorkspaceResponse<ThirdPartyGlobalPayload>> {
  return postWorkspace<ThirdPartyGlobalPayload>("third_party_global", options);
}

export function postSupplierLoginSendCode(
  options: PostWorkspaceOptions = {},
): Promise<LazyWorkspaceResponse<unknown>> {
  return postWorkspace("supplier_login_send_code", options);
}

export function postSupplierLoginVerifyCode(
  options: PostWorkspaceOptions = {},
): Promise<LazyWorkspaceResponse<SupplierLoginPayload>> {
  return postWorkspace<SupplierLoginPayload>("supplier_login_verify_code", options);
}

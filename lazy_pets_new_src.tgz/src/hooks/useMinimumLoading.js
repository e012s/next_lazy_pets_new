"use client";

import { useEffect, useRef, useState } from "react";

/** Default minimum time loading UI stays visible (avoids flash on fast requests). */
export const MIN_LOADING_MS = 1000;

/**
 * Keeps `true` for at least `minMs` after `active` becomes true, even if `active` turns false sooner.
 */
export function useMinimumLoading(active, minMs = MIN_LOADING_MS) {
  const [visible, setVisible] = useState(active);
  const startedAtRef = useRef(null);

  useEffect(() => {
    if (active) {
      startedAtRef.current = Date.now();
      setVisible(true);
      return;
    }

    if (startedAtRef.current === null) {
      setVisible(false);
      return;
    }

    const elapsed = Date.now() - startedAtRef.current;
    const remaining = minMs - elapsed;

    if (remaining <= 0) {
      startedAtRef.current = null;
      setVisible(false);
      return;
    }

    const id = window.setTimeout(() => {
      startedAtRef.current = null;
      setVisible(false);
    }, remaining);

    return () => window.clearTimeout(id);
  }, [active, minMs]);

  return visible;
}

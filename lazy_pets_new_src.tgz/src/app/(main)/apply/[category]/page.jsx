import { Suspense } from "react";
import { notFound } from "next/navigation";
import { Screen } from "@/components/Screen";
import ApplyExpert, { normalizeApplyCategory } from "@/pages/apply/ApplyExpert";

export const metadata = { title: "申請成為專家" };

export function generateStaticParams() {
  return [{ category: "pet" }, { category: "repair" }];
}

function ApplyCategoryFallback() {
  return (
    <div className="min-h-dvh bg-[#f9fafc]">
      <div
        className="mx-auto min-h-dvh w-full max-w-[500px] shadow-[0_0_40px_rgba(16,40,48,0.08)]"
        aria-hidden
      />
    </div>
  );
}

async function ApplyCategoryBody({ params }) {
  const { category: raw } = await params;
  if (raw !== "pet" && raw !== "repair") notFound();
  const category = normalizeApplyCategory(raw);
  return (
    <Screen
      title="申請成為專家"
      backHref="/apply/role"
      headerClassName="h-[52px] shadow-[0_3px_6px_rgba(0,0,0,0.16)]"
      titleClassName="min-w-0 flex-1 truncate text-[16px] leading-[23px] font-bold text-[#797979]"
    >
      <ApplyExpert category={category} />
    </Screen>
  );
}

export default function Page({ params }) {
  return (
    <Suspense fallback={<ApplyCategoryFallback />}>
      <ApplyCategoryBody params={params} />
    </Suspense>
  );
}

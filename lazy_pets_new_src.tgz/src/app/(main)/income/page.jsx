import { Screen } from "@/components/Screen";
import { BottomNav } from "@/components/BottomNav";
import Income from "@/pages/income/Income";
export const metadata = { title: "我的收入" };
export default function Page() {
    return (<Screen title="我的收入" backHref="/" bottomNav={<BottomNav active="income" />}>
      <Income />
    </Screen>);
}

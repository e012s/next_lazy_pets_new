import { notFound } from "next/navigation";
import { Screen } from "@/components/Screen";
import AssignmentDetail from "@/pages/orders/AssignmentDetail";
import PetCompletedDetail from "@/pages/orders/PetCompletedDetail";
import { getAssignment, listMyOrders } from "@/data/mock/assignments";
import { frame } from "@/lib/frame";
export const metadata = { title: "訂單詳情" };
export function generateStaticParams() {
    return listMyOrders().map((order) => ({ id: order.id }));
}
export default function Page({ params }) {
    return frame("訂單詳情", "/orders", "載入訂單…", <Body params={params}/>);
}
async function Body({ params }) {
    const { id } = await params;
    const assignment = getAssignment(id);
    if (!assignment)
        notFound();
    const done = assignment.status === "done";
    return (<Screen title={done ? "已完成訂單詳情" : "訂單詳情"} backHref="/orders">
      {done ? <PetCompletedDetail id={id}/> : <AssignmentDetail id={id}/>}
    </Screen>);
}

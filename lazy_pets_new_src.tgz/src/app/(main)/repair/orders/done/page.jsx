import { Screen } from "@/components/Screen";
import RepairOrdersDone from "@/pages/repair/RepairOrdersDone";
export const metadata = { title: "維修已完成" };
export default function Page() {
    return (<Screen title="已完成" backHref="/repair/orders">
      <RepairOrdersDone />
    </Screen>);
}

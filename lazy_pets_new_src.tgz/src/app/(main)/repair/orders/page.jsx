import { Screen } from "@/components/Screen";
import RepairOrders from "@/pages/repair/RepairOrders";
export const metadata = { title: "維修我的訂單" };
export default function Page() {
    return (<Screen title="我的訂單" backHref="/">
      <RepairOrders />
    </Screen>);
}

import { notFound } from "next/navigation";
import { Screen } from "@/components/Screen";
import RepairReport from "@/pages/repair/RepairReport";
import { getRepairOrder, repairOrders } from "@/data/mock/repair";
import { frame } from "@/lib/frame";
import { reportScreenTitle } from "@/lib/reportFields";
export const metadata = { title: "維修提交報告" };
export function generateStaticParams() {
    return repairOrders.map((order) => ({ id: order.id }));
}
export default function Page({ params }) {
    return frame("今日服務", "/repair/orders", "載入報告…", <Body params={params}/>);
}
async function Body({ params }) {
    const { id } = await params;
    const order = getRepairOrder(id);
    if (!order)
        notFound();
    return (<Screen title={reportScreenTitle(order.title)} backHref="/repair/orders" showMenu flat headerClassName="h-[52px] px-[15px]" titleClassName="min-w-0 flex-1 truncate text-[16px] font-bold text-[#797979]">
      <RepairReport id={id}/>
    </Screen>);
}

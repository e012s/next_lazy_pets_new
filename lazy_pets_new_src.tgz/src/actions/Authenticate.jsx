"use client";

import api from "@/lib/api/Axios.jsx";
import { localLoginSendCode, localLoginVerifyCode } from "@/lib/localAuth";

export async function third_party_global(form = {}, locale) {
  try {
    const res = await api.post(
      "third_party_global",
      form,
      locale ? { params: { locale } } : undefined,
    );
    return res.data;
  } catch {
    return { status: false, message: "獲取全局數據失敗" };
  }
}

export default useAuthenticate;

export function useAuthenticate() {
  return {
    login,
    verification,
    third_party_global,
  };

  async function login(form) {
    return localLoginSendCode(form);
  }

  async function verification(form) {
    return localLoginVerifyCode(form);
  }
}

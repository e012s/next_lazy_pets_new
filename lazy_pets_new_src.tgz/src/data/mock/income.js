const more = [
    ["inc-cl52280", "寄宿 2晚 · 豆豆", "9月3日", 275, 220, "boarding", "豆豆 · 柯基 · 兩晚寄宿，每日散步已完成。"],
    ["inc-cl52271", "散步 30分 · 黑糖", "9月4日", 225, 180, "walk", "黑糖 · 貴婦 · 30 分鐘慢步，有飲水。"],
    ["inc-cl52266", "上門照顧 · 米米", "9月5日", 325, 260, "visit", "米米 · 英短 · 上門餵食同清貓砂。"],
    ["inc-cl52260", "美容 局部 · 小型犬", "9月9日", 188, 150, "groom", "局部修剪腳毛同清耳朵。"],
    ["inc-cl52255", "寄宿 3晚 · 奶茶", "9月11日", 375, 300, "boarding", "奶茶 · 比熊 · 三晚，主人假期附加已計。"],
    ["inc-cl52248", "散步 60分 · 樂樂", "9月13日", 238, 190, "walk", "樂樂 · 唐狗 · 60 分鐘，精神良好。"],
    ["inc-cl52240", "上門照顧 · 布丁", "9月15日", 175, 140, "visit", "布丁 · 兔子 · 換水同檢查乾草。"],
    ["inc-cl52231", "美容 全套 · 貴婦", "9月18日", 250, 200, "groom", "全套洗剪，沒有皮膚紅腫。"],
    ["inc-cl52220", "散步 45分 · 芝麻", "9月21日", 155, 124, "walk", "芝麻 · 柴犬 · 45 分鐘，中途休息一次。"],
    ["inc-cl52211", "陪診 · 安安", "9月24日", 125, 100, "visit", "安安 · 貓 · 陪同覆診，已交回藥單。"],
].map(([id, title, when, orderAmount, payout, icon, summary]) => ({
    id: id,
    featured: false,
    icon: icon,
    title: title,
    meta: `${when} · 訂單 $${orderAmount}`,
    orderLabel: `訂單 $${orderAmount}`,
    orderAmount: orderAmount,
    payout: payout,
    status: "done",
    when: when,
    pet: title,
    summary: summary,
}));
export const incomeRecords = [
    {
        id: "inc-cl52301",
        featured: true,
        icon: "walk",
        title: "散步 60分 · 多多",
        meta: "9月6日 · 訂單 $200",
        orderLabel: "訂單 $200",
        orderAmount: 200,
        payout: 160,
        status: "done",
        when: "9月6日",
        pet: "多多 · 柴犬 · 中型",
        summary: "散步 60 分鐘，精神良好，返屋企後有飲水。皮膚沒有抓到紅。",
    },
    {
        id: "inc-cl52318",
        featured: true,
        icon: "groom",
        title: "美容 全套 · 中型犬",
        meta: "9月6日 · 訂單 $1,050",
        orderLabel: "訂單 $1,050",
        orderAmount: 1050,
        payout: 840,
        status: "done",
        when: "9月6日",
        pet: "金毛 · 中型 · 全套洗剪",
        summary: "全套洗剪完成，風筒用低溫。主人已確認可以交還。",
    },
    {
        id: "inc-cl52322",
        featured: true,
        icon: "visit",
        title: "上門照顧 · 貓貓波波",
        meta: "9月8日 · 訂單 $400（2次）",
        orderLabel: "訂單 $400（2次）",
        orderAmount: 400,
        payout: 320,
        status: "pending",
        when: "9月8日",
        pet: "波波 · 英短 · 兩次上門",
        summary: "第一次上門已完成。第二次尚未開始，所以酬勞仍是待完成。",
    },
    ...more,
];
export const incomeSummary = {
    monthLabel: "9月已完成 · 10月7日發放",
    payout: 2864,
    doneCount: 12,
    pending: 320,
    yearTotal: 24480,
    lastPayout: "2026/09/07 · $3,120",
    notice: "每月 7 號一次過 FPS 過數上月服務酬勞，唔使自己撳提款",
};
export function getIncome(id) {
    return incomeRecords.find((record) => record.id === id);
}
export function donePayoutTotal() {
    return incomeRecords
        .filter((record) => record.status === "done")
        .reduce((sum, record) => sum + record.payout, 0);
}

"use client";

import { navigate } from "@/lib/navigation";

export function RepairOrderTabs({ current }) {
  const tabs = [
    { id: "open", href: "/repair/orders", label: "進行中" },
    { id: "done", href: "/repair/orders/done", label: "已完成" },
  ];
  return (
    <div className="grid grid-cols-2 bg-[#3f4654] text-sm text-[#c5c9d0]" role="tablist">
      {tabs.map((tab) => {
        const active = current === tab.id;
        return (
          <button
            key={tab.id}
            type="button"
            role="tab"
            aria-selected={active}
            onClick={() => navigate(tab.href)}
            className={`flex h-11 items-center justify-center border-b-2${active ? " border-[#7ad4ea] font-medium text-white" : " border-transparent"}`}
          >
            {tab.label}
          </button>
        );
      })}
    </div>
  );
}

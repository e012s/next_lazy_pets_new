import { NextResponse } from "next/server";
import {
    bearerFromCookie,
    entryPathForProfile,
    expertFromAuthorization,
    REGISTERED_COOKIE,
    SESSION_COOKIE,
} from "@/server/expertApi";

const OPEN = new Set(["/login", "/verification"]);

export function proxy(request) {
    const { pathname } = request.nextUrl;
    if (pathname.startsWith("/api/"))
        return NextResponse.next();
    const authorization = bearerFromCookie(request.cookies.get(SESSION_COOKIE)?.value);
    const profile = expertFromAuthorization(authorization, request.cookies.get(REGISTERED_COOKIE)?.value ?? null);
    if (!profile) {
        if (OPEN.has(pathname))
            return NextResponse.next();
        return redirect(request, "/login");
    }
    const home = entryPathForProfile(profile);
    if (pathname === "/login" || pathname === "/verification")
        return redirect(request, home);
    return NextResponse.next();
}
function redirect(request, pathname) {
    const url = request.nextUrl.clone();
    url.pathname = pathname;
    url.search = "";
    return NextResponse.redirect(url);
}
export const config = {
    matcher: ["/((?!_next/static|_next/image|images/|icons/|fonts/|favicon.ico).*)"],
};

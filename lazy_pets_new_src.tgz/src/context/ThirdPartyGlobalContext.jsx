"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { third_party_global } from "@/actions/Authenticate";
import { FullPageLoadingGate } from "@/components/FullPageLoadingGate";
import { loadLocale } from "@/lib/preferences";

const ThirdPartyGlobalContext = createContext(null);

const globalDataCacheByLocale = new Map();
const globalInflightByLocale = new Map();

function localeKey(locale) {
  return locale ?? "cn";
}

function readCachedGlobalData(locale) {
  return globalDataCacheByLocale.get(localeKey(locale)) ?? null;
}

function writeCachedGlobalData(locale, data) {
  if (data != null) {
    globalDataCacheByLocale.set(localeKey(locale), data);
  }
}

async function fetchThirdPartyGlobal(locale, { force = false } = {}) {
  const key = localeKey(locale);

  if (!force) {
    const cached = readCachedGlobalData(locale);
    if (cached) {
      return { status: true, data: cached };
    }
  }

  let inflight = globalInflightByLocale.get(key);
  if (!inflight) {
    inflight = third_party_global({}, locale)
      .then((result) => {
        if (result?.status && result.data) {
          writeCachedGlobalData(locale, result.data);
        }
        return result;
      })
      .finally(() => {
        globalInflightByLocale.delete(key);
      });
    globalInflightByLocale.set(key, inflight);
  }
  return inflight;
}

export function ThirdPartyGlobalProvider({ children }) {
  const locale = loadLocale();
  const [global, setGlobal] = useState(() => readCachedGlobalData(locale));
  const [isLoading, setIsLoading] = useState(() => !readCachedGlobalData(locale));
  const [error, setError] = useState(null);

  const refresh = useCallback(async () => {
    setError(null);
    if (!global) setIsLoading(true);
    try {
      const result = await fetchThirdPartyGlobal(locale, { force: true });
      if (result?.status && result.data) {
        setGlobal(result.data);
        return result.data;
      }
      setError(result?.message ?? "獲取全局數據失敗");
      return null;
    } catch (err) {
      setError(err instanceof Error ? err.message : "獲取全局數據失敗");
      return null;
    } finally {
      setIsLoading(false);
    }
  }, [locale, global]);

  useEffect(() => {
    let cancelled = false;

    const cached = readCachedGlobalData(locale);
    if (cached) {
      setGlobal(cached);
      setIsLoading(false);
      setError(null);
      return undefined;
    }

    setIsLoading(true);
    setError(null);

    (async () => {
      try {
        const result = await fetchThirdPartyGlobal(locale);
        if (cancelled) return;
        if (result?.status && result.data) {
          setGlobal(result.data);
        } else {
          setError(result?.message ?? "獲取全局數據失敗");
        }
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : "獲取全局數據失敗");
        }
      } finally {
        if (!cancelled) setIsLoading(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [locale]);

  const value = useMemo(
    () => ({
      global,
      isLoading,
      error,
      refresh,
      ready: Boolean(global),
    }),
    [global, isLoading, error, refresh],
  );

  return (
    <ThirdPartyGlobalContext.Provider value={value}>
      {children}
      <FullPageLoadingGate active={isLoading && !global} label="載入中…" />
      {error && !global ? (
        <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-background px-6">
          <p className="text-center text-sm leading-5 text-muted">{error}</p>
          <button
            type="button"
            className={`inline-flex h-11 w-full items-center justify-center gap-1 rounded-xl bg-brand px-4 text-title font-medium text-white transition active:bg-brand-active focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand mt-4 max-w-xs`}
            onClick={() => refresh()}
          >
            重試
          </button>
        </div>
      ) : null}
    </ThirdPartyGlobalContext.Provider>
  );
}

export function useThirdPartyGlobal() {
  const ctx = useContext(ThirdPartyGlobalContext);
  if (!ctx) {
    throw new Error("useThirdPartyGlobal must be used within ThirdPartyGlobalProvider");
  }
  return ctx;
}

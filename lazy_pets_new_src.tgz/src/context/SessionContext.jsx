"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";

const SessionContext = createContext(null);

let sessionCache = null;
let sessionInflight = null;
const sessionListeners = new Set();

function notifySessionListeners() {
  for (const listener of sessionListeners) {
    listener(sessionCache);
  }
}

/** Sync session after login / logout without refetching on every route change. */
export function primeSessionCache(data) {
  sessionCache = data?.authenticated ? data : { authenticated: false };
  notifySessionListeners();
}

function fetchSessionJson() {
  if (!sessionInflight) {
    sessionInflight = import("@/lib/clientSession")
      .then(({ readClientSession }) => readClientSession())
      .then((data) => {
        primeSessionCache(data);
        return sessionCache;
      })
      .catch(() => {
        primeSessionCache({ authenticated: false });
        return sessionCache;
      })
      .finally(() => {
        sessionInflight = null;
      });
  }
  return sessionInflight;
}

export function SessionProvider({ children }) {
  const [session, setSession] = useState(sessionCache);

  const refreshSession = useCallback(() => {
    return fetchSessionJson().then((data) => {
      setSession(data);
      return data;
    });
  }, []);

  useEffect(() => {
    sessionListeners.add(setSession);
    return () => {
      sessionListeners.delete(setSession);
    };
  }, []);

  useEffect(() => {
    if (sessionCache) {
      setSession(sessionCache);
      return;
    }
    refreshSession();
  }, [refreshSession]);

  const value = useMemo(
    () => ({ session, refreshSession }),
    [session, refreshSession],
  );

  return <SessionContext.Provider value={value}>{children}</SessionContext.Provider>;
}

export function useSession() {
  const ctx = useContext(SessionContext);
  if (!ctx) {
    throw new Error("useSession must be used within SessionProvider");
  }
  return ctx.session;
}

export function useRefreshSession() {
  const ctx = useContext(SessionContext);
  if (!ctx) {
    throw new Error("useRefreshSession must be used within SessionProvider");
  }
  return ctx.refreshSession;
}
